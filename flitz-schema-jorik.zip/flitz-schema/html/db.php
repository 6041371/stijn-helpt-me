<?php
$host = 'db'; // De naam van je database service in docker-compose
$dbname = 'wedstrijdschema';
$user = 'root';
$pass = 'root'; // VUL DIT IN (bijv. 'root' of wat in je docker config staat)

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $conn = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    // Tip: De error geeft nu specifiek aan wat er misgaat
    die('Database connectie mislukt: ' . $e->getMessage());
}

// De vernieuwde helper functie voor PDO
function db_query($query, $params = [])
{
    global $conn;
    $stmt = $conn->prepare($query);
    $stmt->execute($params); // PDO slikt de array direct, geen str_repeat('s') meer nodig!
    return $stmt;
}
