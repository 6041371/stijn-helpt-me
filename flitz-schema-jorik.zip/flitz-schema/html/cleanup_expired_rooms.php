<?php
// db.php wordt al geincluded door de aanroepende pagina
// Log dat het script werd aangeroepen
error_log("cleanup_expired_rooms.php aangeroepen op " . date('Y-m-d H:i:s'), 3, 'cleanup.log');

global $conn;

// TESTING: 10 seconden
// PRODUCTIE: 86400 (24 uur)
$deletion_interval = 86400; // 24 uur in seconden

try {
    // Zoek alle rooms die ouder zijn dan $deletion_interval seconds
    $stmt = $conn->prepare("SELECT id, name, created_at FROM rooms WHERE created_at <= DATE_SUB(NOW(), INTERVAL ? SECOND)");
    $stmt->execute([$deletion_interval]);
    $old_rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    error_log("Gevonden " . count($old_rooms) . " oude rooms\n", 3, 'cleanup.log');
    
    if (!empty($old_rooms)) {
        foreach ($old_rooms as $room) {
            $room_id = $room['id'];
            $room_name = $room['name'];
            
            // 1. Verwijder matches
            $matches_stmt = $conn->prepare("DELETE FROM matches WHERE room_id = ?");
            $matches_stmt->execute([$room_id]);
            $matches_count = $matches_stmt->rowCount();
            
            // 2. Verwijder game_notes
            $notes_stmt = $conn->prepare("DELETE FROM game_notes WHERE room_id = ?");
            $notes_stmt->execute([$room_id]);
            $notes_count = $notes_stmt->rowCount();
            
            // 3. Verwijder room
            $room_stmt = $conn->prepare("DELETE FROM rooms WHERE id = ?");
            $room_stmt->execute([$room_id]);
            
            error_log("Room $room_id ($room_name) verwijderd\n", 3, 'cleanup.log');
        }
    }
    
} catch (Exception $e) {
    error_log("FOUT: " . $e->getMessage() . "\n", 3, 'cleanup.log');
}
?>
