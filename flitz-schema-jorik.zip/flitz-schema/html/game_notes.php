<?php
require_once 'db.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];


if ($method === 'GET') {
    $room_id = isset($_GET['room_id']) ? intval($_GET['room_id']) : 0;
    $stmt = $conn->prepare('SELECT row_index, note FROM game_notes WHERE room_id = ?');
    $stmt->execute([$room_id]);
    $notes = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // [row_index => note]
    echo json_encode(['success' => true, 'notes' => $notes]);
    exit;
}


if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $room_id = intval($input['room_id'] ?? 0);
    $row_index = intval($input['row_index'] ?? 0);
    $note = $input['note'] ?? '';
    // Upsert
    $stmt = $conn->prepare('INSERT INTO game_notes (room_id, row_index, note) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE note = VALUES(note)');
    $stmt->execute([$room_id, $row_index, $note]);
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid request']);
