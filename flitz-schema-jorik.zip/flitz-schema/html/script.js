// --- GAME NOTES LOGICA ---
function fetchAndUpdateNotes() {
    const params = new URLSearchParams(window.location.search);
    const room = params.get('room');
    if (!room) return;
    const noteInputs = document.querySelectorAll('.note-input');
    if (noteInputs.length === 0) return;
    const room_id = noteInputs[0].dataset.roomId;
    fetch('game_notes.php?room_id=' + encodeURIComponent(room_id))
        .then(res => res.json())
        .then(data => {
            if (data && data.success && data.notes) {
                noteInputs.forEach(input => {
                    const idx = input.dataset.rowIndex;
                    if (!input._isTyping) {
                        input.value = data.notes[idx] || '';
                    }
                });
            }
        });
}

function saveNote(rowIndex, note) {
    const noteInput = document.querySelector('.note-input[data-row-index="' + rowIndex + '"]');
    if (!noteInput) return;
    const room_id = noteInput.dataset.roomId;
    fetch('game_notes.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room_id: room_id, row_index: rowIndex, note: note })
    });
}

document.querySelectorAll('.note-input').forEach(input => {
    input._isTyping = false;
    input.addEventListener('input', function() { this._isTyping = true; });
    input.addEventListener('keydown', function() { this._isTyping = true; });
    input.addEventListener('change', function() {
        saveNote(this.dataset.rowIndex, this.value);
        this._isTyping = false;
    });
    input.addEventListener('blur', function() {
        saveNote(this.dataset.rowIndex, this.value);
        this._isTyping = false;
    });
});

setInterval(fetchAndUpdateNotes, 3000);

// --- LIVE POLLING VOOR REALTIME UPDATES ---
function fetchAndUpdateSchema() {
    const params = new URLSearchParams(window.location.search);
    const room = params.get('room');
    if (!room) return;
    fetch('get_matches.php?room=' + encodeURIComponent(room))
        .then(res => res.json())
        .then(data => {
            if (data && Array.isArray(data)) {
                data.forEach(match => {
                    let row1 = document.querySelector(`.scoreRow[data-team='${match.team1}']`);
                    let row2 = document.querySelector(`.scoreRow[data-team='${match.team2}']`);
                    if (row1) {
                        let cell = row1.querySelector('.round' + match.round_num);
                        if (cell) cell.innerText = match.played ? match.score1 : '';
                    }
                    if (row2) {
                        let cell = row2.querySelector('.round' + match.round_num);
                        if (cell) cell.innerText = match.played ? match.score2 : '';
                    }

                    let slots = document.querySelectorAll(`.match-slot[data-id='${match.id}']`);
                    slots.forEach(slot => {
                        let boxes = slot.querySelectorAll('.team-box, .team-label');
                        let scoreBox = slot.querySelector('.score-box');
                        
                        if (scoreBox) scoreBox.innerText = match.played ? `${match.score1} - ${match.score2}` : 'vs';

                        if (boxes.length === 2) {
                            boxes[0].classList.remove('win','lose','draw');
                            boxes[1].classList.remove('win','lose','draw');
                            if (match.played) {
                                if (match.score1 > match.score2) {
                                    boxes[0].classList.add('win'); boxes[1].classList.add('lose');
                                } else if (match.score1 < match.score2) {
                                    boxes[0].classList.add('lose'); boxes[1].classList.add('win');
                                } else {
                                    boxes[0].classList.add('draw'); boxes[1].classList.add('draw');
                                }
                            }
                        }
                    });
                });
                updateTotal();
                sortRanking();
            }
        });
}
setInterval(fetchAndUpdateSchema, 3000);

// --- POPUP & CLICK LOGICA ---
let currentMatch = {};
let popup = document.getElementById("scorePopup");

document.querySelectorAll(".match-slot").forEach(slot => {
    slot.addEventListener('click', function(e) {
        if (e.target.tagName === 'INPUT') return;
        let dbId = this.dataset.id;
        if (!dbId || dbId === "0") return;

        let round = 0;
        this.classList.forEach(cls => { if (cls.startsWith('r')) round = parseInt(cls.substring(1)); });
        if (round === 0) {
            let wrapper = this.closest('.round-wrapper');
            if (wrapper) round = wrapper.id.replace('round-view-', '');
        }

        let teams = this.querySelectorAll('.team-box, .team-label');
        if (teams.length >= 2) {
            currentMatch = { dbId, round };
            let t1 = teams[0].innerText.replace(/\D/g, "");
            let t2 = teams[1].innerText.replace(/\D/g, "");

            document.getElementById("matchTitle").innerText = `Team ${t1} vs Team ${t2}`;
            document.getElementById("teamAwin").innerText = `🏆 Team ${t1} wint`;
            document.getElementById("teamBwin").innerText = `🏆 Team ${t2} wint`;
            
            document.querySelectorAll("#scorePopup button").forEach(btn => btn.disabled = false);
            popup.style.display = "flex";
        }
    });
});

document.getElementById("teamAwin").onclick = () => finishMatch("A");
document.getElementById("teamBwin").onclick = () => finishMatch("B");
document.getElementById("draw").onclick = () => finishMatch("D");
document.getElementById("cancel").onclick = () => popup.style.display = "none";

function finishMatch(result) {
    let p1 = 0, p2 = 0;
    if (result === "A") { p1 = 3; p2 = 0; }
    else if (result === "B") { p1 = 0; p2 = 3; }
    else if (result === "D") { p1 = 1; p2 = 1; }

    document.querySelectorAll("#scorePopup button").forEach(btn => btn.disabled = true);
    popup.style.display = "none";

    fetch('update_match.php', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${currentMatch.dbId}&score1=${p1}&score2=${p2}`
    }).then(() => fetchAndUpdateSchema());
}

function updateTotal() {
    document.querySelectorAll(".scoreRow").forEach(row => {
        let total = 0;
        row.querySelectorAll(".scoreCell:not(.total)").forEach(cell => {
            let val = parseInt(cell.innerText);
            if (!isNaN(val)) total += val;
        });
        row.querySelector(".total").innerText = total;
    });
}

function sortRanking() {
    let container = document.getElementById("rankingContainer");
    if (!container) return;
    let rows = Array.from(container.querySelectorAll(".scoreRow"));
    rows.sort((a, b) => parseInt(b.querySelector(".total").innerText) - parseInt(a.querySelector(".total").innerText));
    rows.forEach(r => container.appendChild(r));
}

const rondeSelect = document.getElementById('rondeSelect');
if (rondeSelect) {
    rondeSelect.addEventListener('change', function() {
        document.querySelectorAll('.round-wrapper').forEach(w => {
            w.style.display = w.id === 'round-view-' + this.value ? 'block' : 'none';
        });
    });
}