<?php
include 'db.php';

// Functie om rondetafel schema te genereren voor 10 teams
// Elk team speelt tegen elk ander team precies 1 keer
function generateRoundRobinSchedule($numTeams = 10, $numRounds = 9) {
    $schedule = [];
    
    // Initial setup: Team 1 is fixed, teams 2-10 in a line
    $teams = range(1, $numTeams);
    
    for ($round = 0; $round < $numRounds; $round++) {
        $schedule[$round] = [];
        
        // Team 1 (fixed) plays against team at position 9 (last position)
        $schedule[$round][] = [
            'team1' => $teams[0],
            'team2' => $teams[9]
        ];
        
        // Pair up the remaining teams
        for ($i = 1; $i <= 4; $i++) {
            $schedule[$round][] = [
                'team1' => $teams[$i],
                'team2' => $teams[9 - $i]
            ];
        }
        
        // Rotate teams (keep first team fixed, rotate the rest)
        $lastTeam = array_pop($teams);
        array_splice($teams, 1, 0, $lastTeam);
    }
    
    return $schedule;
}

// Generate the schedule
$schedule = generateRoundRobinSchedule(10, 9);

// For this example, let's use room_id = 1 (or you can get it from the form)
$room_id = 1;

// Clear existing matches for room_id if needed (comment out if you want to keep them)
// $conn->prepare("DELETE FROM matches WHERE room_id = ?")->execute([$room_id]);

try {
    $insertCount = 0;
    
    foreach ($schedule as $roundIndex => $matches) {
        $roundNum = $roundIndex + 1;
        
        foreach ($matches as $matchIndex => $match) {
            // Check if match already exists
            $checkStmt = $conn->prepare(
                "SELECT id FROM matches WHERE room_id = ? AND round_num = ? AND match_index = ?"
            );
            $checkStmt->execute([$room_id, $roundNum, $matchIndex + 1]);
            $existing = $checkStmt->fetchColumn();
            
            if (!$existing) {
                $insertStmt = $conn->prepare(
                    "INSERT INTO matches (room_id, round_num, match_index, team1, team2, score1, score2, played) 
                     VALUES (?, ?, ?, ?, ?, NULL, NULL, 0)"
                );
                $insertStmt->execute([
                    $room_id,
                    $roundNum,
                    $matchIndex + 1,
                    $match['team1'],
                    $match['team2']
                ]);
                $insertCount++;
            }
        }
    }
    
    echo "✓ Schema aangemaakt! $insertCount matches toegevoegd aan de database voor room_id=$room_id\n";
    echo "\nSchema overzicht (10 teams, 9 rondes):\n";
    echo "=====================================\n";
    
    foreach ($schedule as $roundIndex => $matches) {
        echo "Ronde " . ($roundIndex + 1) . ":\n";
        foreach ($matches as $matchIndex => $match) {
            echo "  " . $match['team1'] . " vs " . $match['team2'] . "\n";
        }
    }
    
} catch (PDOException $e) {
    die("❌ Database fout: " . $e->getMessage());
}
?>
