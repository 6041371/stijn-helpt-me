-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.dophpmyadmin.net/
--
-- Host: db
-- Gegenereerd op: 02 apr 2026 om 07:05
-- Serverversie: 8.1.0
-- PHP-versie: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wedstrijdschema`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `game_notes`
--

CREATE TABLE `game_notes` (
  `id` int NOT NULL,
  `room_id` int NOT NULL,
  `row_index` int NOT NULL,
  `note` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `game_notes`
--

INSERT INTO `game_notes` (`id`, `room_id`, `row_index`, `note`) VALUES
(46, 17, 1, 'touwtrekken jaden'),
(47, 17, 1, 'touwtrekken jaden'),
(48, 17, 2, ''),
(49, 18, 1, 'touwtrekken'),
(50, 18, 1, 'touwtrekken'),
(51, 18, 1, 'touwtrekken'),
(52, 19, 1, 'egrehtet'),
(53, 19, 1, 'egrehtet'),
(54, 19, 1, 'egrehtet');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `matches`
--

CREATE TABLE `matches` (
  `id` int NOT NULL,
  `room_id` int NOT NULL,
  `round_num` int NOT NULL,
  `match_index` int NOT NULL,
  `team1` int NOT NULL,
  `team2` int NOT NULL,
  `score1` int DEFAULT NULL,
  `score2` int DEFAULT NULL,
  `played` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `matches`
--

INSERT INTO `matches` (`id`, `room_id`, `round_num`, `match_index`, `team1`, `team2`, `score1`, `score2`, `played`) VALUES
(217, 6, 1, 1, 1, 2, 0, 0, 0),
(218, 6, 1, 2, 3, 5, NULL, NULL, 0),
(219, 6, 1, 3, 4, 10, NULL, NULL, 0),
(220, 6, 1, 4, 7, 11, NULL, NULL, 0),
(221, 6, 1, 5, 12, 6, NULL, NULL, 0),
(222, 6, 1, 6, 9, 8, NULL, NULL, 0),
(223, 6, 2, 1, 3, 4, NULL, NULL, 0),
(224, 6, 2, 2, 1, 11, NULL, NULL, 0),
(225, 6, 2, 3, 2, 8, NULL, NULL, 0),
(226, 6, 2, 4, 6, 10, NULL, NULL, 0),
(227, 6, 2, 5, 9, 7, NULL, NULL, 0),
(228, 6, 2, 6, 12, 5, NULL, NULL, 0),
(229, 6, 3, 1, 5, 6, NULL, NULL, 0),
(230, 6, 3, 2, 2, 9, NULL, NULL, 0),
(231, 6, 3, 3, 1, 3, NULL, NULL, 0),
(232, 6, 3, 4, 8, 12, NULL, NULL, 0),
(233, 6, 3, 5, 4, 11, NULL, NULL, 0),
(234, 6, 3, 6, 10, 7, NULL, NULL, 0),
(235, 6, 4, 1, 7, 8, NULL, NULL, 0),
(236, 6, 4, 2, 4, 6, NULL, NULL, 0),
(237, 6, 4, 3, 9, 12, NULL, NULL, 0),
(238, 6, 4, 4, 1, 5, NULL, NULL, 0),
(239, 6, 4, 5, 3, 10, NULL, NULL, 0),
(240, 6, 4, 6, 2, 11, NULL, NULL, 0),
(241, 6, 5, 1, 9, 10, NULL, NULL, 0),
(242, 6, 5, 2, 7, 12, NULL, NULL, 0),
(243, 6, 5, 3, 11, 5, NULL, NULL, 0),
(244, 6, 5, 4, 2, 4, NULL, NULL, 0),
(245, 6, 5, 5, 1, 8, NULL, NULL, 0),
(246, 6, 5, 6, 3, 6, NULL, NULL, 0),
(247, 6, 6, 1, 11, 12, NULL, NULL, 0),
(248, 6, 6, 2, 8, 10, NULL, NULL, 0),
(249, 6, 6, 3, 6, 7, NULL, NULL, 0),
(250, 6, 6, 4, 3, 9, NULL, NULL, 0),
(251, 6, 6, 5, 2, 5, NULL, NULL, 0),
(252, 6, 6, 6, 1, 4, NULL, NULL, 0),
(253, 7, 1, 1, 1, 2, 3, 0, 1),
(254, 7, 1, 2, 3, 5, 3, 0, 1),
(255, 7, 1, 3, 4, 10, NULL, NULL, 0),
(256, 7, 1, 4, 7, 11, NULL, NULL, 0),
(257, 7, 1, 5, 12, 6, NULL, NULL, 0),
(258, 7, 1, 6, 9, 8, NULL, NULL, 0),
(259, 7, 2, 1, 3, 4, 3, 0, 1),
(260, 7, 2, 2, 1, 11, NULL, NULL, 0),
(261, 7, 2, 3, 2, 8, NULL, NULL, 0),
(262, 7, 2, 4, 6, 10, NULL, NULL, 0),
(263, 7, 2, 5, 9, 7, NULL, NULL, 0),
(264, 7, 2, 6, 12, 5, NULL, NULL, 0),
(265, 7, 3, 1, 5, 6, NULL, NULL, 0),
(266, 7, 3, 2, 2, 9, 0, 3, 1),
(267, 7, 3, 3, 1, 3, NULL, NULL, 0),
(268, 7, 3, 4, 8, 12, NULL, NULL, 0),
(269, 7, 3, 5, 4, 11, NULL, NULL, 0),
(270, 7, 3, 6, 10, 7, NULL, NULL, 0),
(271, 7, 4, 1, 7, 8, NULL, NULL, 0),
(272, 7, 4, 2, 4, 6, NULL, NULL, 0),
(273, 7, 4, 3, 9, 12, 3, 0, 1),
(274, 7, 4, 4, 1, 5, NULL, NULL, 0),
(275, 7, 4, 5, 3, 10, NULL, NULL, 0),
(276, 7, 4, 6, 2, 11, NULL, NULL, 0),
(277, 7, 5, 1, 9, 10, 3, 0, 1),
(278, 7, 5, 2, 7, 12, 3, 0, 1),
(279, 7, 5, 3, 11, 5, 3, 0, 1),
(280, 7, 5, 4, 2, 4, 3, 0, 1),
(281, 7, 5, 5, 1, 8, 3, 0, 1),
(282, 7, 5, 6, 3, 6, 3, 0, 1),
(283, 7, 6, 1, 11, 12, 3, 0, 1),
(284, 7, 6, 2, 8, 10, NULL, NULL, 0),
(285, 7, 6, 3, 6, 7, NULL, NULL, 0),
(286, 7, 6, 4, 3, 9, NULL, NULL, 0),
(287, 7, 6, 5, 2, 5, NULL, NULL, 0),
(288, 7, 6, 6, 1, 4, NULL, NULL, 0),
(289, 8, 1, 1, 1, 2, 3, 0, 1),
(290, 8, 1, 2, 3, 5, NULL, NULL, 0),
(291, 8, 1, 3, 4, 10, NULL, NULL, 0),
(292, 8, 1, 4, 7, 11, NULL, NULL, 0),
(293, 8, 1, 5, 12, 6, NULL, NULL, 0),
(294, 8, 1, 6, 9, 8, NULL, NULL, 0),
(295, 8, 2, 1, 3, 4, NULL, NULL, 0),
(296, 8, 2, 2, 1, 11, NULL, NULL, 0),
(297, 8, 2, 3, 2, 8, NULL, NULL, 0),
(298, 8, 2, 4, 6, 10, NULL, NULL, 0),
(299, 8, 2, 5, 9, 7, NULL, NULL, 0),
(300, 8, 2, 6, 12, 5, NULL, NULL, 0),
(301, 8, 3, 1, 5, 6, NULL, NULL, 0),
(302, 8, 3, 2, 2, 9, NULL, NULL, 0),
(303, 8, 3, 3, 1, 3, NULL, NULL, 0),
(304, 8, 3, 4, 8, 12, NULL, NULL, 0),
(305, 8, 3, 5, 4, 11, NULL, NULL, 0),
(306, 8, 3, 6, 10, 7, NULL, NULL, 0),
(307, 8, 4, 1, 7, 8, NULL, NULL, 0),
(308, 8, 4, 2, 4, 6, NULL, NULL, 0),
(309, 8, 4, 3, 9, 12, NULL, NULL, 0),
(310, 8, 4, 4, 1, 5, NULL, NULL, 0),
(311, 8, 4, 5, 3, 10, NULL, NULL, 0),
(312, 8, 4, 6, 2, 11, NULL, NULL, 0),
(313, 8, 5, 1, 9, 10, NULL, NULL, 0),
(314, 8, 5, 2, 7, 12, NULL, NULL, 0),
(315, 8, 5, 3, 11, 5, NULL, NULL, 0),
(316, 8, 5, 4, 2, 4, NULL, NULL, 0),
(317, 8, 5, 5, 1, 8, NULL, NULL, 0),
(318, 8, 5, 6, 3, 6, NULL, NULL, 0),
(319, 8, 6, 1, 11, 12, NULL, NULL, 0),
(320, 8, 6, 2, 8, 10, NULL, NULL, 0),
(321, 8, 6, 3, 6, 7, NULL, NULL, 0),
(322, 8, 6, 4, 3, 9, NULL, NULL, 0),
(323, 8, 6, 5, 2, 5, NULL, NULL, 0),
(324, 8, 6, 6, 1, 4, NULL, NULL, 0),
(325, 9, 1, 1, 1, 2, NULL, NULL, 0),
(326, 9, 1, 2, 3, 5, NULL, NULL, 0),
(327, 9, 1, 3, 4, 10, NULL, NULL, 0),
(328, 9, 1, 4, 7, 11, NULL, NULL, 0),
(329, 9, 1, 5, 12, 6, NULL, NULL, 0),
(330, 9, 1, 6, 9, 8, NULL, NULL, 0),
(331, 9, 2, 1, 3, 4, NULL, NULL, 0),
(332, 9, 2, 2, 1, 11, NULL, NULL, 0),
(333, 9, 2, 3, 2, 8, NULL, NULL, 0),
(334, 9, 2, 4, 6, 10, NULL, NULL, 0),
(335, 9, 2, 5, 9, 7, NULL, NULL, 0),
(336, 9, 2, 6, 12, 5, NULL, NULL, 0),
(337, 9, 3, 1, 5, 6, NULL, NULL, 0),
(338, 9, 3, 2, 2, 9, NULL, NULL, 0),
(339, 9, 3, 3, 1, 3, NULL, NULL, 0),
(340, 9, 3, 4, 8, 12, NULL, NULL, 0),
(341, 9, 3, 5, 4, 11, NULL, NULL, 0),
(342, 9, 3, 6, 10, 7, NULL, NULL, 0),
(343, 9, 4, 1, 7, 8, NULL, NULL, 0),
(344, 9, 4, 2, 4, 6, NULL, NULL, 0),
(345, 9, 4, 3, 9, 12, NULL, NULL, 0),
(346, 9, 4, 4, 1, 5, NULL, NULL, 0),
(347, 9, 4, 5, 3, 10, NULL, NULL, 0),
(348, 9, 4, 6, 2, 11, NULL, NULL, 0),
(349, 9, 5, 1, 9, 10, NULL, NULL, 0),
(350, 9, 5, 2, 7, 12, NULL, NULL, 0),
(351, 9, 5, 3, 11, 5, NULL, NULL, 0),
(352, 9, 5, 4, 2, 4, NULL, NULL, 0),
(353, 9, 5, 5, 1, 8, NULL, NULL, 0),
(354, 9, 5, 6, 3, 6, NULL, NULL, 0),
(355, 9, 6, 1, 11, 12, NULL, NULL, 0),
(356, 9, 6, 2, 8, 10, NULL, NULL, 0),
(357, 9, 6, 3, 6, 7, NULL, NULL, 0),
(358, 9, 6, 4, 3, 9, NULL, NULL, 0),
(359, 9, 6, 5, 2, 5, NULL, NULL, 0),
(360, 9, 6, 6, 1, 4, NULL, NULL, 0),
(361, 10, 1, 1, 1, 2, 3, 0, 1),
(362, 10, 1, 2, 3, 5, NULL, NULL, 0),
(363, 10, 1, 3, 4, 10, NULL, NULL, 0),
(364, 10, 1, 4, 7, 11, NULL, NULL, 0),
(365, 10, 1, 5, 12, 6, NULL, NULL, 0),
(366, 10, 1, 6, 9, 8, NULL, NULL, 0),
(367, 10, 2, 1, 3, 4, 1, 1, 1),
(368, 10, 2, 2, 1, 11, NULL, NULL, 0),
(369, 10, 2, 3, 2, 8, NULL, NULL, 0),
(370, 10, 2, 4, 6, 10, NULL, NULL, 0),
(371, 10, 2, 5, 9, 7, NULL, NULL, 0),
(372, 10, 2, 6, 12, 5, NULL, NULL, 0),
(373, 10, 3, 1, 5, 6, NULL, NULL, 0),
(374, 10, 3, 2, 2, 9, 1, 1, 1),
(375, 10, 3, 3, 1, 3, NULL, NULL, 0),
(376, 10, 3, 4, 8, 12, NULL, NULL, 0),
(377, 10, 3, 5, 4, 11, NULL, NULL, 0),
(378, 10, 3, 6, 10, 7, NULL, NULL, 0),
(379, 10, 4, 1, 7, 8, NULL, NULL, 0),
(380, 10, 4, 2, 4, 6, NULL, NULL, 0),
(381, 10, 4, 3, 9, 12, NULL, NULL, 0),
(382, 10, 4, 4, 1, 5, NULL, NULL, 0),
(383, 10, 4, 5, 3, 10, NULL, NULL, 0),
(384, 10, 4, 6, 2, 11, NULL, NULL, 0),
(385, 10, 5, 1, 9, 10, NULL, NULL, 0),
(386, 10, 5, 2, 7, 12, NULL, NULL, 0),
(387, 10, 5, 3, 11, 5, NULL, NULL, 0),
(388, 10, 5, 4, 2, 4, NULL, NULL, 0),
(389, 10, 5, 5, 1, 8, NULL, NULL, 0),
(390, 10, 5, 6, 3, 6, NULL, NULL, 0),
(391, 10, 6, 1, 11, 12, NULL, NULL, 0),
(392, 10, 6, 2, 8, 10, NULL, NULL, 0),
(393, 10, 6, 3, 6, 7, NULL, NULL, 0),
(394, 10, 6, 4, 3, 9, NULL, NULL, 0),
(395, 10, 6, 5, 2, 5, NULL, NULL, 0),
(396, 10, 6, 6, 1, 4, NULL, NULL, 0),
(397, 11, 1, 1, 1, 2, NULL, NULL, 0),
(398, 11, 1, 2, 3, 5, NULL, NULL, 0),
(399, 11, 1, 3, 4, 10, NULL, NULL, 0),
(400, 11, 1, 4, 7, 11, NULL, NULL, 0),
(401, 11, 1, 5, 12, 6, NULL, NULL, 0),
(402, 11, 1, 6, 9, 8, NULL, NULL, 0),
(403, 11, 2, 1, 3, 4, NULL, NULL, 0),
(404, 11, 2, 2, 1, 11, NULL, NULL, 0),
(405, 11, 2, 3, 2, 8, NULL, NULL, 0),
(406, 11, 2, 4, 6, 10, NULL, NULL, 0),
(407, 11, 2, 5, 9, 7, NULL, NULL, 0),
(408, 11, 2, 6, 12, 5, NULL, NULL, 0),
(409, 11, 3, 1, 5, 6, NULL, NULL, 0),
(410, 11, 3, 2, 2, 9, NULL, NULL, 0),
(411, 11, 3, 3, 1, 3, NULL, NULL, 0),
(412, 11, 3, 4, 8, 12, NULL, NULL, 0),
(413, 11, 3, 5, 4, 11, NULL, NULL, 0),
(414, 11, 3, 6, 10, 7, NULL, NULL, 0),
(415, 11, 4, 1, 7, 8, NULL, NULL, 0),
(416, 11, 4, 2, 4, 6, NULL, NULL, 0),
(417, 11, 4, 3, 9, 12, NULL, NULL, 0),
(418, 11, 4, 4, 1, 5, NULL, NULL, 0),
(419, 11, 4, 5, 3, 10, NULL, NULL, 0),
(420, 11, 4, 6, 2, 11, NULL, NULL, 0),
(421, 11, 5, 1, 9, 10, NULL, NULL, 0),
(422, 11, 5, 2, 7, 12, NULL, NULL, 0),
(423, 11, 5, 3, 11, 5, NULL, NULL, 0),
(424, 11, 5, 4, 2, 4, NULL, NULL, 0),
(425, 11, 5, 5, 1, 8, NULL, NULL, 0),
(426, 11, 5, 6, 3, 6, NULL, NULL, 0),
(427, 11, 6, 1, 11, 12, NULL, NULL, 0),
(428, 11, 6, 2, 8, 10, NULL, NULL, 0),
(429, 11, 6, 3, 6, 7, NULL, NULL, 0),
(430, 11, 6, 4, 3, 9, NULL, NULL, 0),
(431, 11, 6, 5, 2, 5, NULL, NULL, 0),
(432, 11, 6, 6, 1, 4, NULL, NULL, 0),
(433, 12, 1, 1, 1, 2, 3, 0, 1),
(434, 12, 1, 2, 3, 5, 0, 3, 1),
(435, 12, 1, 3, 4, 10, NULL, NULL, 0),
(436, 12, 1, 4, 7, 11, NULL, NULL, 0),
(437, 12, 1, 5, 12, 6, NULL, NULL, 0),
(438, 12, 1, 6, 9, 8, NULL, NULL, 0),
(439, 12, 2, 1, 3, 4, NULL, NULL, 0),
(440, 12, 2, 2, 1, 11, NULL, NULL, 0),
(441, 12, 2, 3, 2, 8, NULL, NULL, 0),
(442, 12, 2, 4, 6, 10, NULL, NULL, 0),
(443, 12, 2, 5, 9, 7, NULL, NULL, 0),
(444, 12, 2, 6, 12, 5, NULL, NULL, 0),
(445, 12, 3, 1, 5, 6, NULL, NULL, 0),
(446, 12, 3, 2, 2, 9, NULL, NULL, 0),
(447, 12, 3, 3, 1, 3, NULL, NULL, 0),
(448, 12, 3, 4, 8, 12, NULL, NULL, 0),
(449, 12, 3, 5, 4, 11, NULL, NULL, 0),
(450, 12, 3, 6, 10, 7, NULL, NULL, 0),
(451, 12, 4, 1, 7, 8, NULL, NULL, 0),
(452, 12, 4, 2, 4, 6, NULL, NULL, 0),
(453, 12, 4, 3, 9, 12, NULL, NULL, 0),
(454, 12, 4, 4, 1, 5, NULL, NULL, 0),
(455, 12, 4, 5, 3, 10, NULL, NULL, 0),
(456, 12, 4, 6, 2, 11, NULL, NULL, 0),
(457, 12, 5, 1, 9, 10, NULL, NULL, 0),
(458, 12, 5, 2, 7, 12, NULL, NULL, 0),
(459, 12, 5, 3, 11, 5, NULL, NULL, 0),
(460, 12, 5, 4, 2, 4, NULL, NULL, 0),
(461, 12, 5, 5, 1, 8, NULL, NULL, 0),
(462, 12, 5, 6, 3, 6, NULL, NULL, 0),
(463, 12, 6, 1, 11, 12, NULL, NULL, 0),
(464, 12, 6, 2, 8, 10, NULL, NULL, 0),
(465, 12, 6, 3, 6, 7, NULL, NULL, 0),
(466, 12, 6, 4, 3, 9, NULL, NULL, 0),
(467, 12, 6, 5, 2, 5, NULL, NULL, 0),
(468, 12, 6, 6, 1, 4, NULL, NULL, 0),
(469, 13, 1, 1, 1, 2, 3, 0, 1),
(470, 13, 1, 2, 3, 5, 1, 1, 1),
(471, 13, 1, 3, 4, 10, 0, 3, 1),
(472, 13, 1, 4, 7, 11, NULL, NULL, 0),
(473, 13, 1, 5, 12, 6, NULL, NULL, 0),
(474, 13, 1, 6, 9, 8, NULL, NULL, 0),
(475, 13, 2, 1, 3, 4, NULL, NULL, 0),
(476, 13, 2, 2, 1, 11, NULL, NULL, 0),
(477, 13, 2, 3, 2, 8, NULL, NULL, 0),
(478, 13, 2, 4, 6, 10, NULL, NULL, 0),
(479, 13, 2, 5, 9, 7, NULL, NULL, 0),
(480, 13, 2, 6, 12, 5, NULL, NULL, 0),
(481, 13, 3, 1, 5, 6, NULL, NULL, 0),
(482, 13, 3, 2, 2, 9, NULL, NULL, 0),
(483, 13, 3, 3, 1, 3, NULL, NULL, 0),
(484, 13, 3, 4, 8, 12, NULL, NULL, 0),
(485, 13, 3, 5, 4, 11, NULL, NULL, 0),
(486, 13, 3, 6, 10, 7, NULL, NULL, 0),
(487, 13, 4, 1, 7, 8, NULL, NULL, 0),
(488, 13, 4, 2, 4, 6, NULL, NULL, 0),
(489, 13, 4, 3, 9, 12, NULL, NULL, 0),
(490, 13, 4, 4, 1, 5, NULL, NULL, 0),
(491, 13, 4, 5, 3, 10, NULL, NULL, 0),
(492, 13, 4, 6, 2, 11, NULL, NULL, 0),
(493, 13, 5, 1, 9, 10, NULL, NULL, 0),
(494, 13, 5, 2, 7, 12, NULL, NULL, 0),
(495, 13, 5, 3, 11, 5, NULL, NULL, 0),
(496, 13, 5, 4, 2, 4, NULL, NULL, 0),
(497, 13, 5, 5, 1, 8, NULL, NULL, 0),
(498, 13, 5, 6, 3, 6, NULL, NULL, 0),
(499, 13, 6, 1, 11, 12, NULL, NULL, 0),
(500, 13, 6, 2, 8, 10, NULL, NULL, 0),
(501, 13, 6, 3, 6, 7, NULL, NULL, 0),
(502, 13, 6, 4, 3, 9, NULL, NULL, 0),
(503, 13, 6, 5, 2, 5, NULL, NULL, 0),
(504, 13, 6, 6, 1, 4, NULL, NULL, 0),
(505, 14, 1, 1, 1, 2, 3, 0, 1),
(506, 14, 1, 2, 3, 5, 0, 3, 1),
(507, 14, 1, 3, 4, 10, NULL, NULL, 0),
(508, 14, 1, 4, 7, 11, NULL, NULL, 0),
(509, 14, 1, 5, 12, 6, NULL, NULL, 0),
(510, 14, 1, 6, 9, 8, NULL, NULL, 0),
(511, 14, 2, 1, 3, 4, 1, 1, 1),
(512, 14, 2, 2, 1, 11, 3, 0, 1),
(513, 14, 2, 3, 2, 8, NULL, NULL, 0),
(514, 14, 2, 4, 6, 10, NULL, NULL, 0),
(515, 14, 2, 5, 9, 7, NULL, NULL, 0),
(516, 14, 2, 6, 12, 5, NULL, NULL, 0),
(517, 14, 3, 1, 5, 6, NULL, NULL, 0),
(518, 14, 3, 2, 2, 9, NULL, NULL, 0),
(519, 14, 3, 3, 1, 3, 3, 0, 1),
(520, 14, 3, 4, 8, 12, 1, 1, 1),
(521, 14, 3, 5, 4, 11, NULL, NULL, 0),
(522, 14, 3, 6, 10, 7, NULL, NULL, 0),
(523, 14, 4, 1, 7, 8, 1, 1, 1),
(524, 14, 4, 2, 4, 6, NULL, NULL, 0),
(525, 14, 4, 3, 9, 12, NULL, NULL, 0),
(526, 14, 4, 4, 1, 5, 3, 0, 1),
(527, 14, 4, 5, 3, 10, NULL, NULL, 0),
(528, 14, 4, 6, 2, 11, NULL, NULL, 0),
(529, 14, 5, 1, 9, 10, NULL, NULL, 0),
(530, 14, 5, 2, 7, 12, NULL, NULL, 0),
(531, 14, 5, 3, 11, 5, NULL, NULL, 0),
(532, 14, 5, 4, 2, 4, NULL, NULL, 0),
(533, 14, 5, 5, 1, 8, 3, 0, 1),
(534, 14, 5, 6, 3, 6, NULL, NULL, 0),
(535, 14, 6, 1, 11, 12, NULL, NULL, 0),
(536, 14, 6, 2, 8, 10, NULL, NULL, 0),
(537, 14, 6, 3, 6, 7, NULL, NULL, 0),
(538, 14, 6, 4, 3, 9, NULL, NULL, 0),
(539, 14, 6, 5, 2, 5, NULL, NULL, 0),
(540, 14, 6, 6, 1, 4, 3, 0, 1),
(541, 15, 1, 1, 1, 2, 1, 1, 1),
(542, 15, 1, 2, 3, 5, 0, 3, 1),
(543, 15, 1, 3, 4, 10, NULL, NULL, 0),
(544, 15, 1, 4, 7, 11, NULL, NULL, 0),
(545, 15, 1, 5, 12, 6, NULL, NULL, 0),
(546, 15, 1, 6, 9, 8, NULL, NULL, 0),
(547, 15, 2, 1, 3, 4, NULL, NULL, 0),
(548, 15, 2, 2, 1, 11, NULL, NULL, 0),
(549, 15, 2, 3, 2, 8, NULL, NULL, 0),
(550, 15, 2, 4, 6, 10, NULL, NULL, 0),
(551, 15, 2, 5, 9, 7, NULL, NULL, 0),
(552, 15, 2, 6, 12, 5, NULL, NULL, 0),
(553, 15, 3, 1, 5, 6, NULL, NULL, 0),
(554, 15, 3, 2, 2, 9, NULL, NULL, 0),
(555, 15, 3, 3, 1, 3, NULL, NULL, 0),
(556, 15, 3, 4, 8, 12, NULL, NULL, 0),
(557, 15, 3, 5, 4, 11, NULL, NULL, 0),
(558, 15, 3, 6, 10, 7, NULL, NULL, 0),
(559, 15, 4, 1, 7, 8, NULL, NULL, 0),
(560, 15, 4, 2, 4, 6, NULL, NULL, 0),
(561, 15, 4, 3, 9, 12, NULL, NULL, 0),
(562, 15, 4, 4, 1, 5, NULL, NULL, 0),
(563, 15, 4, 5, 3, 10, NULL, NULL, 0),
(564, 15, 4, 6, 2, 11, NULL, NULL, 0),
(565, 15, 5, 1, 9, 10, NULL, NULL, 0),
(566, 15, 5, 2, 7, 12, NULL, NULL, 0),
(567, 15, 5, 3, 11, 5, NULL, NULL, 0),
(568, 15, 5, 4, 2, 4, NULL, NULL, 0),
(569, 15, 5, 5, 1, 8, NULL, NULL, 0),
(570, 15, 5, 6, 3, 6, NULL, NULL, 0),
(571, 15, 6, 1, 11, 12, NULL, NULL, 0),
(572, 15, 6, 2, 8, 10, NULL, NULL, 0),
(573, 15, 6, 3, 6, 7, NULL, NULL, 0),
(574, 15, 6, 4, 3, 9, NULL, NULL, 0),
(575, 15, 6, 5, 2, 5, NULL, NULL, 0),
(576, 15, 6, 6, 1, 4, NULL, NULL, 0),
(577, 16, 1, 1, 1, 2, NULL, NULL, 0),
(578, 16, 1, 2, 3, 5, NULL, NULL, 0),
(579, 16, 1, 3, 4, 10, NULL, NULL, 0),
(580, 16, 1, 4, 7, 11, NULL, NULL, 0),
(581, 16, 1, 5, 12, 6, NULL, NULL, 0),
(582, 16, 1, 6, 9, 8, NULL, NULL, 0),
(583, 16, 2, 1, 3, 4, NULL, NULL, 0),
(584, 16, 2, 2, 1, 11, NULL, NULL, 0),
(585, 16, 2, 3, 2, 8, NULL, NULL, 0),
(586, 16, 2, 4, 6, 10, NULL, NULL, 0),
(587, 16, 2, 5, 9, 7, NULL, NULL, 0),
(588, 16, 2, 6, 12, 5, NULL, NULL, 0),
(589, 16, 3, 1, 5, 6, NULL, NULL, 0),
(590, 16, 3, 2, 2, 9, NULL, NULL, 0),
(591, 16, 3, 3, 1, 3, NULL, NULL, 0),
(592, 16, 3, 4, 8, 12, NULL, NULL, 0),
(593, 16, 3, 5, 4, 11, NULL, NULL, 0),
(594, 16, 3, 6, 10, 7, NULL, NULL, 0),
(595, 16, 4, 1, 7, 8, NULL, NULL, 0),
(596, 16, 4, 2, 4, 6, NULL, NULL, 0),
(597, 16, 4, 3, 9, 12, NULL, NULL, 0),
(598, 16, 4, 4, 1, 5, NULL, NULL, 0),
(599, 16, 4, 5, 3, 10, NULL, NULL, 0),
(600, 16, 4, 6, 2, 11, NULL, NULL, 0),
(601, 16, 5, 1, 9, 10, NULL, NULL, 0),
(602, 16, 5, 2, 7, 12, NULL, NULL, 0),
(603, 16, 5, 3, 11, 5, NULL, NULL, 0),
(604, 16, 5, 4, 2, 4, NULL, NULL, 0),
(605, 16, 5, 5, 1, 8, NULL, NULL, 0),
(606, 16, 5, 6, 3, 6, NULL, NULL, 0),
(607, 16, 6, 1, 11, 12, NULL, NULL, 0),
(608, 16, 6, 2, 8, 10, NULL, NULL, 0),
(609, 16, 6, 3, 6, 7, NULL, NULL, 0),
(610, 16, 6, 4, 3, 9, NULL, NULL, 0),
(611, 16, 6, 5, 2, 5, NULL, NULL, 0),
(612, 16, 6, 6, 1, 4, NULL, NULL, 0),
(613, 17, 1, 1, 1, 2, 3, 0, 1),
(614, 17, 1, 2, 3, 5, NULL, NULL, 0),
(615, 17, 1, 3, 4, 10, NULL, NULL, 0),
(616, 17, 1, 4, 7, 11, NULL, NULL, 0),
(617, 17, 1, 5, 12, 6, NULL, NULL, 0),
(618, 17, 1, 6, 9, 8, NULL, NULL, 0),
(619, 17, 2, 1, 3, 4, NULL, NULL, 0),
(620, 17, 2, 2, 1, 11, NULL, NULL, 0),
(621, 17, 2, 3, 2, 8, NULL, NULL, 0),
(622, 17, 2, 4, 6, 10, NULL, NULL, 0),
(623, 17, 2, 5, 9, 7, NULL, NULL, 0),
(624, 17, 2, 6, 12, 5, NULL, NULL, 0),
(625, 17, 3, 1, 5, 6, NULL, NULL, 0),
(626, 17, 3, 2, 2, 9, NULL, NULL, 0),
(627, 17, 3, 3, 1, 3, NULL, NULL, 0),
(628, 17, 3, 4, 8, 12, NULL, NULL, 0),
(629, 17, 3, 5, 4, 11, NULL, NULL, 0),
(630, 17, 3, 6, 10, 7, NULL, NULL, 0),
(631, 17, 4, 1, 7, 8, NULL, NULL, 0),
(632, 17, 4, 2, 4, 6, NULL, NULL, 0),
(633, 17, 4, 3, 9, 12, NULL, NULL, 0),
(634, 17, 4, 4, 1, 5, NULL, NULL, 0),
(635, 17, 4, 5, 3, 10, NULL, NULL, 0),
(636, 17, 4, 6, 2, 11, NULL, NULL, 0),
(637, 17, 5, 1, 9, 10, NULL, NULL, 0),
(638, 17, 5, 2, 7, 12, NULL, NULL, 0),
(639, 17, 5, 3, 11, 5, NULL, NULL, 0),
(640, 17, 5, 4, 2, 4, NULL, NULL, 0),
(641, 17, 5, 5, 1, 8, NULL, NULL, 0),
(642, 17, 5, 6, 3, 6, NULL, NULL, 0),
(643, 17, 6, 1, 11, 12, NULL, NULL, 0),
(644, 17, 6, 2, 8, 10, NULL, NULL, 0),
(645, 17, 6, 3, 6, 7, NULL, NULL, 0),
(646, 17, 6, 4, 3, 9, NULL, NULL, 0),
(647, 17, 6, 5, 2, 5, NULL, NULL, 0),
(648, 17, 6, 6, 1, 4, NULL, NULL, 0),
(649, 18, 1, 1, 1, 2, 3, 0, 1),
(650, 18, 1, 2, 3, 5, 0, 3, 1),
(651, 18, 1, 3, 4, 10, NULL, NULL, 0),
(652, 18, 1, 4, 7, 11, NULL, NULL, 0),
(653, 18, 1, 5, 12, 6, NULL, NULL, 0),
(654, 18, 1, 6, 9, 8, NULL, NULL, 0),
(655, 18, 2, 1, 3, 4, NULL, NULL, 0),
(656, 18, 2, 2, 1, 11, 3, 0, 1),
(657, 18, 2, 3, 2, 8, NULL, NULL, 0),
(658, 18, 2, 4, 6, 10, NULL, NULL, 0),
(659, 18, 2, 5, 9, 7, NULL, NULL, 0),
(660, 18, 2, 6, 12, 5, NULL, NULL, 0),
(661, 18, 3, 1, 5, 6, NULL, NULL, 0),
(662, 18, 3, 2, 2, 9, NULL, NULL, 0),
(663, 18, 3, 3, 1, 3, 3, 0, 1),
(664, 18, 3, 4, 8, 12, NULL, NULL, 0),
(665, 18, 3, 5, 4, 11, NULL, NULL, 0),
(666, 18, 3, 6, 10, 7, NULL, NULL, 0),
(667, 18, 4, 1, 7, 8, NULL, NULL, 0),
(668, 18, 4, 2, 4, 6, NULL, NULL, 0),
(669, 18, 4, 3, 9, 12, NULL, NULL, 0),
(670, 18, 4, 4, 1, 5, NULL, NULL, 0),
(671, 18, 4, 5, 3, 10, NULL, NULL, 0),
(672, 18, 4, 6, 2, 11, NULL, NULL, 0),
(673, 18, 5, 1, 9, 10, NULL, NULL, 0),
(674, 18, 5, 2, 7, 12, NULL, NULL, 0),
(675, 18, 5, 3, 11, 5, NULL, NULL, 0),
(676, 18, 5, 4, 2, 4, NULL, NULL, 0),
(677, 18, 5, 5, 1, 8, NULL, NULL, 0),
(678, 18, 5, 6, 3, 6, NULL, NULL, 0),
(679, 18, 6, 1, 11, 12, NULL, NULL, 0),
(680, 18, 6, 2, 8, 10, NULL, NULL, 0),
(681, 18, 6, 3, 6, 7, NULL, NULL, 0),
(682, 18, 6, 4, 3, 9, NULL, NULL, 0),
(683, 18, 6, 5, 2, 5, NULL, NULL, 0),
(684, 18, 6, 6, 1, 4, NULL, NULL, 0),
(685, 19, 1, 1, 1, 2, 3, 0, 1),
(686, 19, 1, 2, 3, 5, NULL, NULL, 0),
(687, 19, 1, 3, 4, 10, NULL, NULL, 0),
(688, 19, 1, 4, 7, 11, NULL, NULL, 0),
(689, 19, 1, 5, 12, 6, NULL, NULL, 0),
(690, 19, 1, 6, 9, 8, NULL, NULL, 0),
(691, 19, 2, 1, 3, 4, NULL, NULL, 0),
(692, 19, 2, 2, 1, 11, NULL, NULL, 0),
(693, 19, 2, 3, 2, 8, NULL, NULL, 0),
(694, 19, 2, 4, 6, 10, NULL, NULL, 0),
(695, 19, 2, 5, 9, 7, NULL, NULL, 0),
(696, 19, 2, 6, 12, 5, NULL, NULL, 0),
(697, 19, 3, 1, 5, 6, NULL, NULL, 0),
(698, 19, 3, 2, 2, 9, NULL, NULL, 0),
(699, 19, 3, 3, 1, 3, NULL, NULL, 0),
(700, 19, 3, 4, 8, 12, NULL, NULL, 0),
(701, 19, 3, 5, 4, 11, NULL, NULL, 0),
(702, 19, 3, 6, 10, 7, NULL, NULL, 0),
(703, 19, 4, 1, 7, 8, NULL, NULL, 0),
(704, 19, 4, 2, 4, 6, NULL, NULL, 0),
(705, 19, 4, 3, 9, 12, NULL, NULL, 0),
(706, 19, 4, 4, 1, 5, NULL, NULL, 0),
(707, 19, 4, 5, 3, 10, NULL, NULL, 0),
(708, 19, 4, 6, 2, 11, NULL, NULL, 0),
(709, 19, 5, 1, 9, 10, NULL, NULL, 0),
(710, 19, 5, 2, 7, 12, NULL, NULL, 0),
(711, 19, 5, 3, 11, 5, NULL, NULL, 0),
(712, 19, 5, 4, 2, 4, NULL, NULL, 0),
(713, 19, 5, 5, 1, 8, NULL, NULL, 0),
(714, 19, 5, 6, 3, 6, NULL, NULL, 0),
(715, 19, 6, 1, 11, 12, NULL, NULL, 0),
(716, 19, 6, 2, 8, 10, NULL, NULL, 0),
(717, 19, 6, 3, 6, 7, NULL, NULL, 0),
(718, 19, 6, 4, 3, 9, NULL, NULL, 0),
(719, 19, 6, 5, 2, 5, NULL, NULL, 0),
(720, 19, 6, 6, 1, 4, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `rooms`
--

CREATE TABLE `rooms` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `teams` int DEFAULT NULL,
  `game` varchar(100) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Gegevens worden geëxporteerd voor tabel `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `teams`, `game`) VALUES
(1, 'test', 12, 'Zeskamp'),
(17, 'test2', 12, 'Zeskamp'),
(18, 'rogier', 12, 'Zeskamp'),
(19, 'fesef', 12, 'Zeskamp');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `game_notes`
--
ALTER TABLE `game_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexen voor tabel `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `game_notes`
--
ALTER TABLE `game_notes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT voor een tabel `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=721;

--
-- AUTO_INCREMENT voor een tabel `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `game_notes`
--
ALTER TABLE `game_notes`
  ADD CONSTRAINT `game_notes_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
