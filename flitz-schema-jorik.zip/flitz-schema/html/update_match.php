<?php
include 'db.php';

if (isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $s1 = (int)$_POST['score1'];
    $s2 = (int)$_POST['score2'];

    $stmt = $conn->prepare("UPDATE matches SET score1 = ?, score2 = ?, played = 1 WHERE id = ?");
    $stmt->execute([$s1, $s2, $id]);
    echo "Success";
}
?>