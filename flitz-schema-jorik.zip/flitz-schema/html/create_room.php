<?php
include 'db.php';

$room_name = $_POST['room_name'] ?? '';
$teams = (int)($_POST['teams'] ?? 12);
$game = $_POST['game'] ?? 'Zeskamp';

if (!$room_name || $teams < 2) {
    echo json_encode(['success' => false, 'error' => 'Ongeldige invoer!']);
    exit;
}

// 1. Check of room bestaat
$stmt = db_query("SELECT id FROM rooms WHERE name = ?", [$room_name]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Room bestaat al!']);
    exit;
}

// 2. Voeg room toe
db_query("INSERT INTO rooms (name, teams, game) VALUES (?, ?, ?)", [$room_name, $teams, $game]);
global $conn; // <-- voeg deze regel toe als hij er niet staat!
$room_id = $conn->lastInsertId();

// 3. Genereer wedstrijden gebaseerd op aantal teams
if ($teams == 4) {
    // Flexibel schema voor 4 teams - 6 spellen en 6 rondes
    $matches_to_create = [
        // Ronde 1
        ['round' => 1, 'match_index' => 1, 'team1' => 1, 'team2' => 2],
        ['round' => 1, 'match_index' => 2, 'team1' => 3, 'team2' => 4],
        // Ronde 2
        ['round' => 2, 'match_index' => 3, 'team1' => 1, 'team2' => 3],
        ['round' => 2, 'match_index' => 4, 'team1' => 2, 'team2' => 4],
        // Ronde 3
        ['round' => 3, 'match_index' => 5, 'team1' => 1, 'team2' => 4],
        ['round' => 3, 'match_index' => 6, 'team1' => 2, 'team2' => 3],
        // Ronde 4
        ['round' => 4, 'match_index' => 1, 'team1' => 3, 'team2' => 4],
        ['round' => 4, 'match_index' => 2, 'team1' => 1, 'team2' => 2],
        // Ronde 5
        ['round' => 5, 'match_index' => 3, 'team1' => 2, 'team2' => 4],
        ['round' => 5, 'match_index' => 4, 'team1' => 1, 'team2' => 3],
        // Ronde 6
        ['round' => 6, 'match_index' => 5, 'team1' => 2, 'team2' => 3],
        ['round' => 6, 'match_index' => 6, 'team1' => 1, 'team2' => 4],
    ];
    
    global $conn;
    foreach ($matches_to_create as $match) {
        $checkStmt = $conn->prepare(
            "SELECT id FROM matches WHERE room_id = ? AND round_num = ? AND match_index = ?"
        );
        $checkStmt->execute([$room_id, $match['round'], $match['match_index']]);
        if (!$checkStmt->fetchColumn()) {
            db_query(
                "INSERT INTO matches (room_id, round_num, match_index, team1, team2) VALUES (?, ?, ?, ?, ?)",
                [$room_id, $match['round'], $match['match_index'], $match['team1'], $match['team2']]
            );
        }
    }
} elseif ($teams == 6) {
    // Flexibel schema voor 6 teams - altijd 6 spellen en 6 rondes
    // Format: ['round' => ronde, 'match_index' => spel, 'team1' => team1, 'team2' => team2]
    $matches_to_create = [
        // Ronde 1
        ['round' => 1, 'match_index' => 1, 'team1' => 1, 'team2' => 2],
        ['round' => 1, 'match_index' => 2, 'team1' => 3, 'team2' => 4],
        ['round' => 1, 'match_index' => 3, 'team1' => 5, 'team2' => 6],
        // Ronde 2
        ['round' => 2, 'match_index' => 1, 'team1' => 3, 'team2' => 5],
        ['round' => 2, 'match_index' => 2, 'team1' => 1, 'team2' => 6],
        ['round' => 2, 'match_index' => 3, 'team1' => 2, 'team2' => 4],
        // Ronde 3
        ['round' => 3, 'match_index' => 1, 'team1' => 4, 'team2' => 6],
        ['round' => 3, 'match_index' => 2, 'team1' => 2, 'team2' => 5],
        ['round' => 3, 'match_index' => 3, 'team1' => 1, 'team2' => 3],
        // Ronde 4
        ['round' => 4, 'match_index' => 4, 'team1' => 6, 'team2' => 2],
        ['round' => 4, 'match_index' => 5, 'team1' => 5, 'team2' => 4],
        ['round' => 4, 'match_index' => 6, 'team1' => 3, 'team2' => 1],
        // Ronde 5
        ['round' => 5, 'match_index' => 4, 'team1' => 3, 'team2' => 5],
        ['round' => 5, 'match_index' => 5, 'team1' => 1, 'team2' => 6],
        ['round' => 5, 'match_index' => 6, 'team1' => 2, 'team2' => 4],
        // Ronde 6
        ['round' => 6, 'match_index' => 4, 'team1' => 4, 'team2' => 1],
        ['round' => 6, 'match_index' => 5, 'team1' => 2, 'team2' => 3],
        ['round' => 6, 'match_index' => 6, 'team1' => 6, 'team2' => 5],
    ];
    
    global $conn;
    foreach ($matches_to_create as $match) {
        $checkStmt = $conn->prepare(
            "SELECT id FROM matches WHERE room_id = ? AND round_num = ? AND match_index = ?"
        );
        $checkStmt->execute([$room_id, $match['round'], $match['match_index']]);
        if (!$checkStmt->fetchColumn()) {
            db_query(
                "INSERT INTO matches (room_id, round_num, match_index, team1, team2) VALUES (?, ?, ?, ?, ?)",
                [$room_id, $match['round'], $match['match_index'], $match['team1'], $match['team2']]
            );
        }
    }
} elseif ($teams == 10) {
    // Schema voor 10 teams (5 rondes, 5 matches per ronde)
    $schema = [
        [1,2, 3,4, 5,6, 7,8, 9,10],      // Ronde 1: 1v2, 3v4, 5v6, 7v8, 9v10
        [9,4, 1,6, 3,8, 5,10, 7,2],      // Ronde 2: 9v4, 1v6, 3v8, 5v10, 7v2
        [7,6, 9,8, 1,10, 3,2, 5,4],      // Ronde 3: 7v6, 9v8, 1v10, 3v2, 5v4
        [5,8, 7,10, 9,2, 1,4, 3,6],      // Ronde 4: 5v8, 7v10, 9v2, 1v4, 3v6
        [3,10, 5,2, 7,4, 9,6, 1,8]       // Ronde 5: 3v10, 5v2, 7v4, 9v6, 1v8
    ];
    $num_rounds = 5;
    $matches_per_round = 5;
} else {
    // Schema voor 12 teams (6 rondes, 6 matches per ronde) - default
    $schema = [
        [1,2,3,5,4,10,7,11,12,6,9,8],
        [3,4,1,11,2,8,6,10,9,7,12,5],   
        [5,6,2,9,1,3,8,12,4,11,10,7],
        [7,8,4,6,9,12,1,5,3,10,2,11],
        [9,10,7,12,11,5,2,4,1,8,3,6],
        [11,12,8,10,6,7,3,9,2,5,1,4]
    ];
    $num_rounds = 6;
    $matches_per_round = 6;
}

// Voor 10 en 12 teams: gebruik het schema-systeem
if ($teams == 10 || $teams == 12) {
    for ($round = 1; $round <= $num_rounds; $round++) {
        global $conn;
        $row = $schema[$round-1];
        file_put_contents('debug_roomid.txt', $room_id);
        for ($match = 1; $match <= $matches_per_round; $match++) {
            $team1 = $row[($match-1)*2];
            $team2 = $row[($match-1)*2+1];
            $result = db_query("INSERT INTO matches (room_id, round_num, match_index, team1, team2) VALUES (?, ?, ?, ?, ?)", [$room_id, $round, $match, $team1, $team2]);
            if (!$result) {
                file_put_contents('debug_match_error.txt', "Fout bij match: room_id=$room_id, round=$round, match=$match, team1=$team1, team2=$team2\n", FILE_APPEND);
            } else {
                file_put_contents('debug_match_insert.txt', "room_id=$room_id, round=$round, match=$match, team1=$team1, team2=$team2\n", FILE_APPEND);
            }
        }
    }
}

// Voor 10 teams: zet 'Finale' als notitie voor rij 6
if ($teams == 10) {
    global $conn;
    $checkStmt = $conn->prepare("SELECT id FROM game_notes WHERE room_id = ? AND row_index = ?");
    $checkStmt->execute([$room_id, 6]);
    if (!$checkStmt->fetchColumn()) {
        db_query("INSERT INTO game_notes (room_id, row_index, note) VALUES (?, ?, ?)", [$room_id, 6, 'Finale']);
    }
}

echo json_encode(['success' => true, 'room_id' => $room_id, 'teams' => $teams]);
