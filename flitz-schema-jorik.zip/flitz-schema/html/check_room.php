<?php
include 'db.php';

$room_name = $_GET['room'] ?? '';

if (!$room_name) {
    echo json_encode(['exists' => false, 'message' => 'Room naam vereist']);
    exit;
}

$stmt = $conn->prepare("SELECT id, teams FROM rooms WHERE name = ?");
$stmt->execute([$room_name]);
$room = $stmt->fetch(PDO::FETCH_ASSOC);

if ($room) {
    echo json_encode(['exists' => true, 'teams' => $room['teams']]);
} else {
    echo json_encode(['exists' => false, 'message' => 'Room bestaat niet']);
}
?>
