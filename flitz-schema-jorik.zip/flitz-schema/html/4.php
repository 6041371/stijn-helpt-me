<?php
include 'db.php';
include 'cleanup_expired_rooms.php';

$room_id = 1;
$game_name = 'Zeskamp';
if (isset($_GET['room'])) {
    $stmt = $conn->prepare("SELECT id, game FROM rooms WHERE name = ?");
    $stmt->execute([$_GET['room']]);
    $room = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$room) {
        header("Location: index.html");
        exit;
    }
    $room_id = $room['id'];
    $game_name = $room['game'] ?? 'Zeskamp';
}

try {
    $stmt = $conn->prepare("SELECT * FROM matches WHERE room_id = ? ORDER BY round_num, match_index");
    $stmt->execute([$room_id]);
    $all_matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $match_map = [];
    foreach ($all_matches as $m) {
        $match_map[$m['round_num']][$m['match_index']] = $m;
    }
} catch (PDOException $e) {
    die("Database fout: " . $e->getMessage());
}

$team_scores = [];
for ($t = 1; $t <= 4; $t++) {
    for ($r = 1; $r <= 6; $r++) {
        $team_scores[$t][$r] = 0;
    }
}

foreach ($all_matches as $m) {
    if (!empty($m['played'])) {
        $team_scores[$m['team1']][$m['round_num']] += (int)$m['score1'];
        $team_scores[$m['team2']][$m['round_num']] += (int)$m['score2'];
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($game_name); ?> - 4 Teams</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* --- UI LOGICA --- */
        .mobile-ui { display: none; }
        .desktop-ui { display: block; }

        @media (max-width: 767px) {
            .desktop-ui { display: none; }
            .mobile-ui { display: block; }
            
            .container { padding: 5px; width: 100%; box-sizing: border-box; overflow-x: hidden; }
            
            .filter-container {
                background: white;
                padding: 10px;
                border-radius: 12px;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }
            .styled-select {
                padding: 6px 10px;
                border-radius: 8px;
                border: 1px solid #ddd;
                font-size: 14px;
                flex-grow: 1;
            }

            .mobile-table-header {
                display: flex;
                justify-content: space-between;
                background: #f39c12;
                color: white;
                padding: 10px;
                border-radius: 10px 10px 0 0;
                font-weight: bold;
                font-size: 14px;
            }
            
            .match-row-mobile {
                display: grid;
                grid-template-columns: 25px 1fr 50px 1fr;
                align-items: center;
                background: white;
                padding: 10px 5px;
                border-bottom: 1px solid #eee;
                text-align: center;
                cursor: pointer;
            }

            .team-label {
                padding: 6px 2px;
                border-radius: 6px;
                font-size: 13px;
                background: #f8f9fa;
                pointer-events: none; 
                white-space: nowrap;
                overflow: hidden;
            }
            .team-label.win { background-color: #d4edda; color: #155724; font-weight: bold; }
            .team-label.lose { background-color: #f8d7da; color: #721c24; }
            .team-label.draw { background-color: #fff3cd; color: #856404; }
            
            .score-box { font-weight: bold; font-size: 14px; color: #333; pointer-events: none; }
            .match-idx { color: #888; font-size: 12px; pointer-events: none; }

            /* --- PUNTESTAND MOBIEL --- */
            .scoreHeader, .scoreRow {
                display: flex !important;
                width: 100%;
                gap: 4px;
                margin-bottom: 4px;
                background: none;
                padding: 0;
                border: none;
            }

            .scoreHeader > div, .scoreRow > div {
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 13px;
                height: 45px;
                border-radius: 6px;
                box-sizing: border-box;
                margin: 0;
                padding: 0;
                text-align: center;
            }

            .teamName, .scoreHeader > div:first-child {
                flex: 0 0 85px !important; 
                background: #f39c12;
                color: white;
                font-weight: bold;
                justify-content: center !important;
            }

            .scoreRow .teamName {
                background: white;
                color: #333;
                border: 1px solid #eee;
            }

            .scoreCell, .scoreHeader > div:not(:first-child):not(:last-child) {
                flex: 1;
                background: #f0e2cc;
                color: #8a7b63; 
                min-width: 0;
            }
            
            .scoreRow .scoreCell {
                color: #333; 
            }

            .scoreCell.total, .scoreHeader > div:last-child {
                flex: 1;
                background: #e67e22;
                color: white !important;
                font-weight: bold;
            }
        }
    </style>
</head>
<body>

    <h1><?php echo htmlspecialchars($game_name); ?><style { text-align: center; }></style></h1>
    <h2 style="text-align:center;">4 Teams</h2>

    <div class="container">
        
        <div class="mobile-ui">
            <div class="filter-container">
                <span>Ronde:</span>
                <select id="rondeSelect" class="styled-select">
                    <?php for ($r = 1; $r <= 6; $r++): ?>
                        <option value="<?php echo $r; ?>">Ronde <?php echo $r; ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="mobile-matches-container">
                <div class="mobile-table-header">
                    <div>Match</div>
                    <div>Uitslag</div>
                </div>
                <?php
                for ($r = 1; $r <= 6; $r++) {
                    echo "<div class='round-wrapper' id='round-view-$r' style='display: " . ($r == 1 ? 'block' : 'none') . ";'>";
                    // Up to 6 possible match slots, though 4 teams usually use fewer
                    for ($i = 1; $i <= 6; $i++) {
                        $match = $match_map[$r][$i] ?? null;
                        if ($match) {
                            $c1 = $c2 = '';
                            if (!empty($match['played'])) {
                                if ($match['score1'] > $match['score2']) { $c1 = 'win'; $c2 = 'lose'; }
                                elseif ($match['score1'] < $match['score2']) { $c1 = 'lose'; $c2 = 'win'; }
                                else { $c1 = $c2 = 'draw'; }
                            }
                            $scoreText = ($match['played']) ? "{$match['score1']} - {$match['score2']}" : "vs";
                            echo "<div class='match-row-mobile match-slot' data-id='" . ($match['id'] ?? 0) . "'>";
                            echo "<div class='match-idx'>$i</div>";
                            echo "<div class='team-label $c1'>T{$match['team1']}</div>";
                            echo "<div class='score-box'>$scoreText</div>";
                            echo "<div class='team-label $c2'>T{$match['team2']}</div>";
                            echo "</div>";
                        }
                    }
                    echo "</div>";
                }
                ?>
            </div>
        </div>

        <div class="desktop-ui">
            <div class="header">
                <div>Games</div>
                <?php for($r=1; $r<=6; $r++) echo "<div>Ronde $r</div>"; ?>
            </div>
            <?php
            for ($i = 1; $i <= 6; $i++) {
                echo '<div class="match-row">';
                echo '<div class="game-input"><input type="text" class="note-input" data-row-index="' . $i . '" data-room-id="' . $room_id . '"></div>';
                for ($r = 1; $r <= 6; $r++) {
                    $match = $match_map[$r][$i] ?? null;
                    echo "<div class='match-slot r$r' data-id='" . ($match['id'] ?? 0) . "'>";
                    if ($match) {
                        $class1 = $class2 = '';
                        if (!empty($match['played'])) {
                            if ($match['score1'] > $match['score2']) { $class1 = 'win'; $class2 = 'lose'; }
                            elseif ($match['score1'] < $match['score2']) { $class1 = 'lose'; $class2 = 'win'; }
                            else { $class1 = $class2 = 'draw'; }
                        }
                        echo "<div class='team-box $class1' data-team='" . $match['team1'] . "'>" . $match['team1'] . "</div>";
                        echo "<div class='team-box $class2' data-team='" . $match['team2'] . "'>" . $match['team2'] . "</div>";
                    }
                    echo "</div>";
                }
                echo '</div>';
            }
            ?>
        </div>

        <div class="scoreTitle">Puntenstand</div>

        <div class="scoreHeader">
            <div>Team</div>
            <div>R1</div><div>R2</div><div>R3</div><div>R4</div><div>R5</div><div>R6</div>
            <div>Tot.</div>
        </div>

        <div id="rankingContainer">
            <?php
            $team_rows = [];
            for ($t = 1; $t <= 4; $t++) {
                $total = 0;
                for ($r = 1; $r <= 6; $r++) { $total += $team_scores[$t][$r]; }
                $team_rows[] = ['team' => $t, 'total' => $total, 'scores' => $team_scores[$t]];
            }
            usort($team_rows, function($a, $b) { return $b['total'] <=> $a['total']; });
            
            foreach ($team_rows as $row) {
                $t = $row['team'];
                echo '<div class="scoreRow" data-team="' . $t . '">';
                echo '<div class="teamName">Team ' . $t . '</div>';
                for ($r = 1; $r <= 6; $r++) {
                    $val = $row['scores'][$r];
                    echo '<div class="scoreCell round'.$r.'">'.($val === 0 ? '' : $val).'</div>';
                }
                echo '<div class="scoreCell total">'.$row['total'].'</div>';
                echo '</div>';
            }
            ?>
        </div>
    </div>

    <div id="scorePopup" class="popup">
        <div class="popupBox">
            <h3 id="matchTitle"></h3>
            <button id="teamAwin"></button>
            <button id="draw">🤝 Gelijkspel</button>
            <button id="teamBwin"></button>
            <button id="cancel">Annuleren</button>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        // Handle mobile round switching
        document.getElementById('rondeSelect')?.addEventListener('change', function() {
            document.querySelectorAll('.round-wrapper').forEach(el => el.style.display = 'none');
            const target = document.getElementById('round-view-' + this.value);
            if(target) target.style.display = 'block';
        });
    </script>
</body>
</html>