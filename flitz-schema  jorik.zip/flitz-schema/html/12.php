<?php
include 'db.php';


// Haal room_id op basis van roomnaam uit de URL
$room_id = 1;
if (isset($_GET['room'])) {
	$stmt = $conn->prepare("SELECT id FROM rooms WHERE name = ?");
	$stmt->execute([$_GET['room']]);
	$room_id = $stmt->fetchColumn();
	if (!$room_id) {
		die("Room niet gevonden!");
	}
}
try {
	$stmt = $conn->prepare("SELECT * FROM matches WHERE room_id = ? ORDER BY round_num, match_index");
	$stmt->execute([$room_id]);
	$all_matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

	$match_map = [];
	foreach ($all_matches as $m) {
		$match_map[$m['round_num']][$m['match_index']] = $m;
	}
} catch (PDOException $e) {
	die("Database fout: " . $e->getMessage());
}

// Scores per team per ronde initialiseren
$team_scores = [];
for ($t = 1; $t <= 12; $t++) {
    for ($r = 1; $r <= 6; $r++) {
        $team_scores[$t][$r] = 0;
    }
}
// Vul de scores uit de database, alleen als gespeeld
foreach ($all_matches as $m) {
	if (!empty($m['played']) && ($m['score1'] > 0 || $m['score2'] > 0)) {
		$team_scores[$m['team1']][$m['round_num']] += (int)$m['score1'];
		$team_scores[$m['team2']][$m['round_num']] += (int)$m['score2'];
	} else {
		// Zorg dat lege scores echt leeg zijn
		if (!isset($team_scores[$m['team1']][$m['round_num']])) $team_scores[$m['team1']][$m['round_num']] = '';
		if (!isset($team_scores[$m['team2']][$m['round_num']])) $team_scores[$m['team2']][$m['round_num']] = '';
	}
}

?>

<!DOCTYPE html>
<html lang="nl">

<head>
	<meta charset="UTF-8">
	<title>Zeskamp - 12 Teams</title>
	<link rel="stylesheet" href="style.css">
</head>

<body>

	<h1>Zeskamp</h1>
	<h2>12 Teams</h2>

	<div class="container">
		<div class="header">
			<div>Games</div>
			<div>Ronde 1</div>
			<div>Ronde 2</div>
			<div>Ronde 3</div>
			<div>Ronde 4</div>
			<div>Ronde 5</div>
			<div>Ronde 6</div>
		</div>

		<?php
		for ($i = 1; $i <= 6; $i++) {
			echo '<div class="match-row">';
			// Notitieveld met data-row-index en data-room-id
			echo '<div class="game-input"><input type="text" class="note-input" data-row-index="' . $i . '" data-room-id="' . $room_id . '"></div>';

			for ($r = 1; $r <= 6; $r++) {
				$match = $match_map[$r][$i] ?? null;
				echo "<div class='match-slot r$r' data-id='" . ($match['id'] ?? 0) . "'>";
				if ($match) {
					// Bepaal de status alleen als er gespeeld is én minstens één score > 0
					$class1 = $class2 = '';
					if (!empty($match['played']) && ($match['score1'] > 0 || $match['score2'] > 0)) {
						if ($match['score1'] > $match['score2']) {
							$class1 = 'win';
							$class2 = 'lose';
						} elseif ($match['score1'] < $match['score2']) {
							$class1 = 'lose';
							$class2 = 'win';
						} else {
							$class1 = $class2 = 'draw';
						}
					}
					echo "<div class='team-box $class1' data-team='" . $match['team1'] . "'>" . $match['team1'] . "</div>";
					echo "<div class='team-box $class2' data-team='" . $match['team2'] . "'>" . $match['team2'] . "</div>";
				}
				echo "</div>";
			}
			echo '</div>';
		}
		?>

		<div class="scoreTitle">Puntenstand</div>

		<div class="scoreHeader">
			<div>Team</div>
			<div>R1</div>
			<div>R2</div>
			<div>R3</div>
			<div>R4</div>
			<div>R5</div>
			<div>R6</div>
			<div>Totaal</div>
		</div>

		<?php
		// Verzamel alle teams met hun totalen
		$team_rows = [];
		for ($t = 1; $t <= 12; $t++) {
			$total = 0;
			for ($r = 1; $r <= 6; $r++) {
				$total += $team_scores[$t][$r];
			}
			$team_rows[] = ['team' => $t, 'total' => $total];
		}
		// Sorteer op totaal, hoogste eerst
		usort($team_rows, function($a, $b) { return $b['total'] <=> $a['total']; });
		// Toon de scoreRows in gesorteerde volgorde
		foreach ($team_rows as $row) {
			$t = $row['team'];
			echo '<div class="scoreRow" data-team="' . $t . '">';
			echo '<div class="teamName">Team ' . $t . '</div>';
			$total = 0;
			for ($r = 1; $r <= 6; $r++) {
				$score = $team_scores[$t][$r];
				if ($score === '' || $score === null) {
					echo '<div class="scoreCell round'.$r.'"></div>';
				} else {
					$total += $score;
					echo '<div class="scoreCell round'.$r.'">'.$score.'</div>';
				}
			}
			echo '<div class="scoreCell total">'.$total.'</div>';
			echo '</div>';
		}
		?>

	</div>

	<!-- Score Popup Modal -->
	<div id="scorePopup" class="popup">
		<div class="popupBox">
			<h3 id="matchTitle"></h3>
			<button id="teamAwin"></button>
			<button id="draw">🤝 Gelijkspel</button>
			<button id="teamBwin"></button>
			<button id="cancel">Annuleren</button>
		</div>
	</div>

</body>
<script src="script.js"></script>

</html>