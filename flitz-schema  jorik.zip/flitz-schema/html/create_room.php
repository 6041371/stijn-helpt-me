<?php
include 'db.php';

$room_name = $_POST['room_name'] ?? '';
$teams = (int)($_POST['teams'] ?? 12);
$game = $_POST['game'] ?? 'Zeskamp';

if (!$room_name || $teams < 2) {
    echo json_encode(['success' => false, 'error' => 'Ongeldige invoer!']);
    exit;
}

// 1. Check of room bestaat
$stmt = db_query("SELECT id FROM rooms WHERE name = ?", [$room_name]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Room bestaat al!']);
    exit;
}

// 2. Voeg room toe
db_query("INSERT INTO rooms (name, teams, game) VALUES (?, ?, ?)", [$room_name, $teams, $game]);
global $conn; // <-- voeg deze regel toe als hij er niet staat!
$room_id = $conn->lastInsertId();

// 3. Genereer wedstrijden voor 12 teams (6 rondes, 6 matches per ronde)
// Dit is een voorbeeldschema, pas aan naar jouw wensen
$schema = [
    [1,2,3,5,4,10,7,11,12,6,9,8],
    [3,4,1,11,2,8,6,10,9,7,12,5],   
    [5,6,2,9,1,3,8,12,4,11,10,7],
    [7,8,4,6,9,12,1,5,3,10,2,11],
    [9,10,7,12,11,5,2,4,1,8,3,6],
    [11,12,8,10,6,7,3,9,2,5,1,4]
];

for ($round = 1; $round <= 6; $round++) {
global $conn; // <-- voeg deze regel toe als hij er niet staat!
    $row = $schema[$round-1];
file_put_contents('debug_roomid.txt', $room_id);
    for ($match = 1; $match <= 6; $match++) {
        $team1 = $row[($match-1)*2];
        $team2 = $row[($match-1)*2+1];
        $result = db_query("INSERT INTO matches (room_id, round_num, match_index, team1, team2) VALUES (?, ?, ?, ?, ?)", [$room_id, $round, $match, $team1, $team2]);
        if (!$result) {
            file_put_contents('debug_match_error.txt', "Fout bij match: room_id=$room_id, round=$round, match=$match, team1=$team1, team2=$team2\n", FILE_APPEND);
        } else {
            file_put_contents('debug_match_insert.txt', "room_id=$room_id, round=$round, match=$match, team1=$team1, team2=$team2\n", FILE_APPEND);
        }
    }
}

echo json_encode(['success' => true, 'room_id' => $room_id]);
