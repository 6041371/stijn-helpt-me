// --- GAME NOTES LOGICA ---
// --- GAME NOTES LOGICA ---
function fetchAndUpdateNotes() {
	const params = new URLSearchParams(window.location.search);
	const room = params.get('room');
	if (!room) return;
	const noteInputs = document.querySelectorAll('.note-input');
	if (noteInputs.length === 0) return;
	const room_id = noteInputs[0].dataset.roomId;
	fetch('game_notes.php?room_id=' + encodeURIComponent(room_id))
		.then(res => res.json())
		.then(data => {
			if (data && data.success && data.notes) {
				noteInputs.forEach(input => {
					const idx = input.dataset.rowIndex;
					// Alleen bijwerken als input NIET gefocust is EN niet aan het typen
					if (!input._isTyping) {
						input.value = data.notes[idx] || '';
					}
				});
			}
		});
}

function saveNote(rowIndex, note) {
	const noteInput = document.querySelector('.note-input[data-row-index="' + rowIndex + '"]');
	if (!noteInput) return;
	const room_id = noteInput.dataset.roomId;
	fetch('game_notes.php', {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify({ room_id: room_id, row_index: rowIndex, note: note })
	});
}

// Event listeners voor notitievelden
document.querySelectorAll('.note-input').forEach(input => {
	input._isTyping = false;
	input.addEventListener('input', function() {
		this._isTyping = true;
	});
	input.addEventListener('keydown', function() {
		this._isTyping = true;
	});
	input.addEventListener('change', function() {
		saveNote(this.dataset.rowIndex, this.value);
		this._isTyping = false;
	});
	input.addEventListener('blur', function() {
		saveNote(this.dataset.rowIndex, this.value);
		this._isTyping = false;
	});
});

// Poll elke 3 seconden voor notities
setInterval(fetchAndUpdateNotes, 3000);
fetchAndUpdateNotes(); // Initieel ophalen
// --- LIVE POLLING VOOR REALTIME UPDATES ---
function fetchAndUpdateSchema() {
	// Haal roomnaam uit de URL
	const params = new URLSearchParams(window.location.search);
	const room = params.get('room');
	if (!room) return;
	fetch('get_matches.php?room=' + encodeURIComponent(room))
		.then(res => res.json())
		.then(data => {
			if (data && Array.isArray(data)) {
				// Reset alle scores en kleuren
				document.querySelectorAll('.scoreCell').forEach(cell => { if (!cell.classList.contains('total')) cell.innerText = ''; });
				document.querySelectorAll('.team-box').forEach(box => { box.classList.remove('win','lose','draw'); });

				// Zet nieuwe scores en kleuren
				data.forEach(match => {
					// Scoretabel
					let row1 = document.querySelector(`.scoreRow[data-team='${match.team1}']`);
					let row2 = document.querySelector(`.scoreRow[data-team='${match.team2}']`);
					if (row1) {
						let cell = row1.querySelector('.round' + match.round_num);
						if (cell) cell.innerText = match.score1 > 0 ? match.score1 : '';
					}
					if (row2) {
						let cell = row2.querySelector('.round' + match.round_num);
						if (cell) cell.innerText = match.score2 > 0 ? match.score2 : '';
					}

					// Team-box kleuren
					let slots = document.querySelectorAll(`.match-slot[data-id='${match.id}']`);
					slots.forEach(slot => {
						let boxes = slot.querySelectorAll('.team-box');
						if (boxes.length === 2) {
							boxes[0].classList.remove('win','lose','draw');
							boxes[1].classList.remove('win','lose','draw');
							if (match.score1 > 0 || match.score2 > 0) {
								if (match.score1 > match.score2) {
									boxes[0].classList.add('win'); boxes[1].classList.add('lose');
								} else if (match.score1 < match.score2) {
									boxes[0].classList.add('lose'); boxes[1].classList.add('win');
								} else {
									boxes[0].classList.add('draw'); boxes[1].classList.add('draw');
								}
							}
						}
					});
				});
				updateTotal();
				sortRanking();
			}
		});
}
setInterval(fetchAndUpdateSchema, 3000); // elke 3 seconden
let playedMatches = {}
let currentMatch = {}
let popup = document.getElementById("scorePopup")

// Synchronisatie helpers
function serializeSchema() {
	// Haal alle cellen en hun klassen op
	return Array.from(document.querySelectorAll('.schemaRow')).map(row =>
		Array.from(row.querySelectorAll('.cell')).map(cell => ({
			team: cell.dataset.team,
			round: cell.dataset.round,
			class: cell.className
		}))
	);
}
function serializeScores() {
	return Array.from(document.querySelectorAll('.scoreRow')).map(row =>
	({
		team: row.dataset.team,
		rounds: Array.from(row.querySelectorAll('.scoreCell')).map(cell => cell.innerText)
	})
	);
}
function applyRemoteSchema(schema, scores, remotePlayedMatches) {
	// Cell klassen herstellen
	if (schema) {
		document.querySelectorAll('.schemaRow').forEach((row, i) => {
			let cells = row.querySelectorAll('.cell');
			schema[i]?.forEach((cell, j) => {
				cells[j].className = cell.class;
			});
		});
	}
	// Scores herstellen
	if (scores) {
		document.querySelectorAll('.scoreRow').forEach((row, i) => {
			let roundCells = row.querySelectorAll('.scoreCell');
			scores[i]?.rounds?.forEach((val, j) => {
				roundCells[j].innerText = val;
			});
		});
		updateTotal();
		sortRanking();
	}
	// Gespeelde wedstrijden herstellen
	if (remotePlayedMatches) {
		playedMatches = { ...remotePlayedMatches };
	}
}
window.applyRemoteSchema = applyRemoteSchema;



// Maak elke team-box klikbaar zodat de match-popup opent
document.querySelectorAll(".match-slot").forEach(slot => {
	let teamBoxes = slot.querySelectorAll('.team-box');
	if (teamBoxes.length < 2) return;
	let dbId = slot.dataset.id;
	let round = 0;
	slot.classList.forEach(cls => {
		if (cls.startsWith('r')) {
			let nr = parseInt(cls.substring(1));
			if (!isNaN(nr)) round = nr;
		}
	});
	let matchId = dbId;
	// Beide teams krijgen een click event
	teamBoxes[0].addEventListener('click', function(e) {
		e.stopPropagation();
		openMatchCustom(teamBoxes[0], teamBoxes[1], matchId, round, dbId);
	});
	teamBoxes[1].addEventListener('click', function(e) {
		e.stopPropagation();
		openMatchCustom(teamBoxes[0], teamBoxes[1], matchId, round, dbId);
	});
});

function openMatchCustom(teamA, teamB, matchId, round, dbId) {
	// Altijd toestaan om een wedstrijd opnieuw te openen
	currentMatch = { teamA, teamB, matchId, round, dbId };

	let t1 = teamA.innerText;
	let t2 = teamB.innerText;

	document.getElementById("matchTitle").innerText = "Team " + t1 + " vs Team " + t2;
	document.getElementById("teamAwin").innerText = "🏆 Team " + t1 + " wint";
	document.getElementById("teamBwin").innerText = "🏆 Team " + t2 + " wint";

	document.getElementById("teamAwin").disabled = false;
	document.getElementById("teamBwin").disabled = false;
	document.getElementById("draw").disabled = false;
	document.getElementById("cancel").disabled = false;

	popup.style.display = "flex";
}

function openMatch(teamA, teamB, matchId) {
	if (playedMatches[matchId]) return

	// Haal de ronde uit het data-round attribuut van teamA (of teamB, want ze zijn gelijk)
	let round = teamA.dataset.round;

	currentMatch = { teamA, teamB, matchId, round };

	let t1 = teamA.dataset.team
	let t2 = teamB.dataset.team

	document.getElementById("matchTitle").innerText = "Team " + t1 + " vs Team " + t2

	document.getElementById("teamAwin").innerText = "🏆 Team " + t1 + " wint"
	document.getElementById("teamBwin").innerText = "🏆 Team " + t2 + " wint"

	// Enable buttons when popup opens
	document.getElementById("teamAwin").disabled = false;
	document.getElementById("teamBwin").disabled = false;
	document.getElementById("draw").disabled = false;
	document.getElementById("cancel").disabled = false;

	popup.style.display = "flex"
}


document.getElementById("teamAwin").onclick = () => handlePopupButton("A");
document.getElementById("teamBwin").onclick = () => handlePopupButton("B");
document.getElementById("draw").onclick = () => handlePopupButton("D");
document.getElementById("cancel").onclick = () => handlePopupButton("C");

function handlePopupButton(result) {
	if (result === "C") {
		popup.style.display = "none";
		return;
	}
	// Disable all buttons immediately to prevent double input, but only for scoring actions
	document.getElementById("teamAwin").disabled = true;
	document.getElementById("teamBwin").disabled = true;
	document.getElementById("draw").disabled = true;
	document.getElementById("cancel").disabled = true;
	finishMatch(result);
}

function finishMatch(result) {
	let { teamA, teamB, matchId, round, dbId } = currentMatch;

	let team1Num = teamA.innerText;
	let team2Num = teamB.innerText;

	let pA = 0;
	let pB = 0;

	// Reset oude kleuren
	teamA.classList.remove("win", "lose", "draw");
	teamB.classList.remove("win", "lose", "draw");

	if (result === "A") {
		pA = 3; pB = 0;
		teamA.classList.add("win");   // Groen
		teamB.classList.add("lose");  // Rood
	} else if (result === "B") {
		pA = 0; pB = 3;
		teamA.classList.add("lose");  // Rood
		teamB.classList.add("win");   // Groen
	} else if (result === "D") {
		pA = 1; pB = 1;
		teamA.classList.add("draw");  // Geel
		teamB.classList.add("draw");  // Geel
	}

	// Puntenstand tabel updaten
	updateScore(team1Num, round, pA);
	updateScore(team2Num, round, pB);

	playedMatches[matchId] = true;
	updateTotal();
	sortRanking();

	popup.style.display = "none";

	// Update naar de database (AJAX)
	fetch('update_match.php', { 
		method: 'POST',
		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body: `id=${dbId}&score1=${pA}&score2=${pB}`
	})
	.then(response => response.text())
	.then(data => console.log("Opgeslagen:", data))
	.catch(err => console.error("Fout:", err));
}

function updateScore(team, round, points) {

	let row = document.querySelector(`.scoreRow[data-team='${team}']`)

	row.querySelector(".round" + round).innerText = points

}

function updateTotal() {

	document.querySelectorAll(".scoreRow").forEach(row => {

		let total = 0

		for (let r = 1; r <= 6; r++) {

			let val = row.querySelector(".round" + r).innerText

			if (val != "") total += parseInt(val)

		}

		row.querySelector(".total").innerText = total

	})

}

function sortRanking() {

	let rows = Array.from(document.querySelectorAll(".scoreRow"))

	rows.sort((a, b) => {

		let ta = parseInt(a.querySelector(".total").innerText)
		let tb = parseInt(b.querySelector(".total").innerText)

		return tb - ta

	})

	let container = rows[0].parentNode

	rows.forEach(r => container.appendChild(r))

}