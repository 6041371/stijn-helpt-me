<?php
include 'db.php';


// Ophalen van room_id op basis van roomnaam (indien nodig)
if (isset($_GET['room_id'])) {
    $room_id = (int)$_GET['room_id'];
} elseif (isset($_GET['room'])) {
    $stmt = $conn->prepare("SELECT id FROM rooms WHERE name = ?");
    $stmt->execute([$_GET['room']]);
    $room_id = $stmt->fetchColumn();
    if (!$room_id) {
        http_response_code(404);
        echo json_encode(["error" => "Room niet gevonden"]);
        exit;
    }
} else {
    $room_id = 1; // fallback, maar eigenlijk wil je hier een foutmelding
}

try {
    // We gebruiken een prepared statement voor de veiligheid
    $stmt = $conn->prepare("
        SELECT id, round_num, match_index, team1, team2, score1, score2, played 
        FROM matches 
        WHERE room_id = ? 
        ORDER BY round_num, match_index
    ");

    $stmt->execute([$room_id]);

    // PDO kan in één keer alles ophalen als een array van associatieve arrays
    $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Stuur het resultaat terug als JSON
    header('Content-Type: application/json');
    echo json_encode($matches);
} catch (PDOException $e) {
    // Als er iets misgaat, stuur een foutmelding in JSON formaat
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}
